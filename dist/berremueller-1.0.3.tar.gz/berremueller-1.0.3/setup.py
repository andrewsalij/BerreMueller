import setuptools
setuptools.setup()

